<?php
include 'dbconnection.php';
$registration_date = date('Y-m-d H:i:s');

// Get the raw JSON input from the POST request
$input = json_decode(file_get_contents('php://input'), true);

// Check if all data is set (data1: IP, data2: latitude, data3: longitude)
if (isset($input['data1']) && isset($input['data2']) && isset($input['data3'])) {
    // Assign the data to variables
    $ipAddress = $input['data1'];
    $latitude = $input['data2'];
    $longitude = $input['data3'];

    // Prepare and execute the SQL query to insert the data into the "locationip" table
    $sql = "INSERT INTO ip_log (registration_date, ipAddress, latitude, longitude) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdd",$registration_date, $ipAddress, $latitude, $longitude);  // Modified to include Fullname and registration_date

    if ($stmt->execute()) {
        // Display the data after saving it to the database
       /* echo "<h3>Data Saved Successfully</h3>";
        echo "<p>IP Address: " . htmlspecialchars($ipAddress) . "</p>";
        echo "<p>Latitude: " . htmlspecialchars($latitude) . "</p>";
        echo "<p>Longitude: " . htmlspecialchars($longitude) . "</p>";
        echo "<p>Full Name: " . htmlspecialchars($Fullname) . "</p>";  // Display Fullname
        echo "<p>Registration Date: " . htmlspecialchars($registration_date) . "</p>";  // Display registration_date*/
    } else {
        echo "<p>Error saving data: " . $stmt->error . "</p>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "<p>Invalid data received.</p>";
}
?>
