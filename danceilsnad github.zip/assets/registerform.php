<?php
// Include the database connection file
include 'dbconnection.php'; // Adjust the path if necessary

// Retrieve form data
$fname = $_POST['fname'];
$surname = $_POST['sname'];
$age = $_POST['age'];
$birthdate = $_POST['birthdate'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$tel = $_POST['tel'];
$email = $_POST['email'];
$facebook = $_POST['facebook'];
$instagram = $_POST['instagram'];
$dances = isset($_POST['dances']) ? implode(", ", $_POST['dances']) : '';
$registration_date = date("Y-m-d H:i:s");

$Fullname = $_POST['Fullname'];
$contact_name = $_POST['contact_name'];
$contact_phone = $_POST['contact_phone'];
$health_issues = $_POST['health_issues'];
$salsaExp = $_POST['salsaExp'];
$bachataExp = $_POST['bachataExp'];
$kizombaExp = $_POST['kizombaExp'];
$afrostyleExp = $_POST['afrostyleExp'];
$ladystyleExp = $_POST['ladystyleExp'];
$otherDanceExp = $_POST['otherDanceExp'];

try {
    // Begin a transaction
    $conn->begin_transaction();

    // Prepare the first SQL query for 'reg_forms'
    $stmt1 = $conn->prepare("INSERT INTO reg_forms (fname, sname, age, birthdate, gender, address, tel, email, facebook, instagram, dances, registration_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt1 === false) {
        throw new Exception("Prepare failed for reg_forms: " . $conn->error);
    }
    
    // Bind parameters for the first query
    $stmt1->bind_param("ssssssssssss", $fname, $surname, $age, $birthdate, $gender, $address, $tel, $email, $facebook, $instagram, $dances, $registration_date);

    // Execute the first query
    if (!$stmt1->execute()) {
        throw new Exception("Execution failed for reg_forms: " . $stmt1->error);
    }

    // Prepare the second SQL query for 'additional_reg_form'
    $stmt2 = $conn->prepare("INSERT INTO additional_reg_form (Fullname, contact_name, contact_phone, health_issues, salsaExp, bachataExp, kizombaExp, afrostyleExp, ladystyleExp, otherDanceExp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt2 === false) {
        throw new Exception("Prepare failed for additional_reg_form: " . $conn->error);
    }

    // Bind parameters for the second query
    $stmt2->bind_param("ssssssssss", $Fullname, $contact_name, $contact_phone, $health_issues, $salsaExp, $bachataExp, $kizombaExp, $afrostyleExp, $ladystyleExp, $otherDanceExp);

    // Execute the second query
    if (!$stmt2->execute()) {
        throw new Exception("Execution failed for additional_reg_form: " . $stmt2->error);
    }

    // Commit the transaction
    $conn->commit();

    header("Location: congrats.html");

} catch (Exception $e) {
    // Rollback the transaction if something goes wrong
    $conn->rollback();
    header("Location: tryagain.html");
  }

// Close the prepared statements and connection
$stmt1->close();
$stmt2->close();
$conn->close();
?>
