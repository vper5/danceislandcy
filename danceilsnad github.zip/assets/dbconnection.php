
<?php

// These variables define the connnection information for your MySQL database
$servername = "localhost:3306";   
$username = "u5xnzx87mujp";
$password = "222389Hosting!";
$dbname = "danceislandform";


// Create connnection

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error)
{
die("connection failed".$conn->connect_error);
}	
{
//echo "connection successful";
} 

mysqli_set_charset($conn, 'utf8mb4');

return $conn;

?>