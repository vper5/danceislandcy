<?php
  $registration_date = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>DanceIslandCy</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS
    ================================================== -->
     
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/socialmedia.css">
    <link rel="stylesheet" href="css/style.css">
 
    

    <!-- script
    ================================================== -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/pace.min.js"></script>
    


    <!-- favicons
    ================================================== -->
    <link rel="shortcut icon" href="assets/DIcon.ico" type="image/x-icon">
    <link rel="icon" href="assets/DIcon.ico" type="image/x-icon">


<meta name="google-site-verification" content="HGWZzXsmX7rw8caWwMkbufJQPv_BxFt00137YDCaoho" />

</head>

<body>


    <!-- Placeholders to display IP address and location -->
    <p id="ip-address" hidden >Fetching IP Address...</p>
    <p id="location"hidden>Fetching Location...</p>
  

    <!-- home
    ================================================== -->
    <main class="s-home s-home--static">

        <div class="overlay"></div>

        <div class="home-content">

            <div class="home-logo">
                <a href="index.html">
                    <img src="images/logoDanceisland.png" alt="Homepage">
                </a>
            </div>

            <div class="row home-content__main">

               
                    <h3> We are currently working <br>
                        on our website.</h3>

                    <h1>
                        Our "Motto" 
                    </h1>
                    <h2 >" It's not Just Another Hobby <br>
                        &nbsp; &nbsp; ... It's a way of life!!! "</h2>
                    

                    <div class="home-content__subscribe">
                        <h3>Wanna be a <br>dancer?</h3>
                          <form id="mc-form" class="group">
                        <input type="submit" id="register-button" name="submit" value="Click For Register">
                        </form>                   
                    </div>

                    <div class="social-menu">
                        <span class="badge badge-info"><h5>FOLLOW US ON SOCIAL MEDIA</h5></span>
                        <ul>
                            <li><a href="https://www.facebook.com/VasilisMarinaDanceislandcy/"     target="_blank" title="VasilisMarinaDanceislandcy" ><i class="fab fa-facebook"></i></i></a></li>
                            <li><a href="https://www.facebook.com/DanceIslandCy/"                  target="blank"  title="DanceIslandCy"><i class="fab fa-facebook"></i></i></a></li>
                            <li><a href="https://www.instagram.com/danceislandcy"                  target="blank"  title="danceislandcy"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="https://www.youtube.com/@DanceIslandCy"                   target="blank"  title="DanceIslandCy"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="https://www.danceislandcy.com"                            target="blank"  title="Webpage"><i class="fab fa-connectdevelop	"></i></a></li>
                            <li><a href="0035797932635"   target="blank"  title="Whats Up"><i class="fab fa-whatsapp"></i></a></li>
                        </ul>
                    </div>

               

                <div class="col-four home-content__counter">
                  
                    </div>  <!-- end home-content__clock -->
                

            </div>  <!-- end home-content__main -->


            <div class="row home-copyright">
                <span>DanceislandCy © 2024 | All Rights Reserved</span> 
                <span>Design by &nbsp; <a href="">DanceislandCy</a></span>
            </div> <!-- end home-copyright -->

            <div class="home-content__line"></div>

        </div> <!-- end home-content -->

    </main> <!-- end s-home -->

    <!-- info
    ================================================== -->
    <a class="info-toggle" href="#0">
        <span class="info-menu-icon"></span>
    </a>

    <div class="s-info">

        <div class="row info-wrapper">
          
            <div class="col-seven tab-full info-main">
                <h1>Dance Island Enrollment Form</h1>
               <!------------------------------------------------------------>
               


               <div class="main">
                <div class="container">
                    <form id="signup-form" action="assets/registerform.php" method="POST" >
                        
                        <h3>
                            Personal Info
                        </h3>
                        <fieldset>
                            <h2>Personal information </h2>
                            <p class="desc">Please enter your infomation and proceed to the next step so you can complete your Register</p>
                            <div class="form-group ">
                                <label class="label" for="fname">First Name:</label> <!--oninput="updateFullName()" js for autofill full name-->
                                    <input type="text" class="form-control" name="fname"  id="fname" placeholder="First Name * " oninput="updateFullName()"  required> 
                                </div>
                                <div class="form-group">
                                <label class="label" for="sname">Last Name:</label>
                                    <input type="text" class="form-control" name="sname"  id="sname" placeholder="Last Name *" oninput="updateFullName()" required>
                                </div>
                                <div class="form-group">
                                <label class="label" for="age">Age</label>
                                    <input type="number" minlength="1" maxlength="2" class="form-control" id="age" name="age" placeholder="Age *"  required/>
                                </div>
                                <div class="form-group">
                                <label class="label" for="bdate">Birthdate:</label>
                                    <input type="date" class="form-control"  id="birthdate" name="birthdate" placeholder="Birthdate *"  required/>
                                </div>
                                <div class="form-group">
                                <label class="label" for="gender">Gender:</label>
                                <select name="gender" id="gender" class="form-control"  required>
                                        <option  selected disabled >None</option>
                                        <option>Male</option>
                                        <option>Female</option>
                                        <option>Other</option>
                                    </select>
                                </div>
                             </fieldset>
        <!-- -->
                        <h3>
                            Contact Info
                        </h3>
                        <fieldset>
                            <h2> Contact Infomation</h2>
                            <div class="form-group">
                                <label class="label" for="fname">Address:</label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="Address" >
                                </div>
                                <div class="form-group">
                                <label class="label" for="fname">Telephone number:</label>
                                    <input type="tel" minlength="8" maxlength="15"  id="tel" name="tel" class="form-control" placeholder="Telephone number*" required>
                                </div>
                                <div class="form-group">
                                <label class="label" for="fname">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                                </div>
                                <div class="form-group">
                                <label class="label" for="fname">Facebook:</label>
                                <input type="text" class="form-control" id="facebook" name="facebook" placeholder="facebook.com/YourAccountname"> 
                                </div>
                                <div class="form-group">
                                <label class="label" for="fname">Instagram:</label>
                                <input type="text" class="form-control" id="instagram" name="instagram"placeholder="instagram.com/YourAccountname/"> 
                                </div>
                        </fieldset>
        
                        <h3>
                            Dance Style
                        </h3>
                        <fieldset> 
                            <h2>Choose the Dances you want to learn</h2>
                            <div class="form-group">
                                <label for="salsa">Salsa</label><br>
                                <input type="checkbox" id="salsa" name="dances[]" value="Salsa">
                                <label for="bachata">Bachata</label><br>
                                <input type="checkbox" id="bachata" name="dances[]" value="Bachata">
                                <label for="kizomba">Kizomba</label><br>
                                <input type="checkbox" id="kizomba" name="dances[]" value="Kizomba">
                                <label for="lady_style">Lady Style</label><br>
                                <input type="checkbox" id="lady_style" name="dances[]" value="Lady Style">
                                <label for="afro_style">AfroStyle</label><br>
                                <input type="checkbox" id="afro_style" name="dances[]" value="Afro Style">
                            </div>
                        </fieldset>
        
                        <h3>
                            Additional Info
                        </h3>
                        <fieldset> 
                            <h2>Emergency Contact Information </h2>
                            <p class="desc">We need this information in case of an emergency.</p>
        
                            <div class="form-group ">
                                <label for="Fullname">Your Full Name</label>
                                <input type="text"class="form-control" id="Fullname" name="Fullname" readonly >
                               </div>
                               <div class="form-group ">
                                <label for="contact_name">Contact Name*</label>
                                <input type="text"class="form-control" id="contact_name" name="contact_name" placeholder="Contact Name" required>
                               </div>
                               <div class="form-group">
                                <label for="contact_phone">Contact Phone Number* </label>
                                <input type="tel" minlength="8" maxlength="15" class="form-control" id="contact_phone" name="contact_phone"  placeholder="Contact Phone Number" required>
                               </div>
                              <div class="form-group">
                              <label for="health_issues">Health Issues</label>
                             <textarea  rows="50" cols="65" class="form-control" id="health_issues" name="health_issues" ></textarea>
                               </div>
                        </fieldset>
        
                        <h3>
                            Dance Experience
                        </h3>
                        <fieldset> 
                            <h2>Answer if you have Previous Dance Experience</h2>
                            <div class="form-group">
                                <label for="salsa-experience">Salsa Experience   &nbsp;&nbsp;&nbsp;&nbsp;</label>
                                <select class="form-control" id="salsaExp" name="salsaExp">
                                   <option value="none">None</option>
                                   <option value="beginner">Beginner</option>
                                   <option value="intermediate">Intermediate</option>
                                   <option value="advanced">Advanced</option>
                               </select>
                           </div>
                           <div class="form-group">
                               <label for="bachata-experience">Bachata Experience &nbsp;</label>
                               <select class="form-control" id="bachataExp" name="bachataExp">
                                   <option value="none">None</option>
                                   <option value="beginner">Beginner</option>
                                   <option value="intermediate">Intermediate</option>
                                   <option value="advanced">Advanced</option>
                               </select>
                           </div>
                           <div class="form-group">
                               <label for="kizomba-experience">Kizomba Experience &nbsp;</label>
                               <select class="form-control" id="kizombaExp" name="kizombaExp">
                                   <option value="none">None</option>
                                   <option value="beginner">Beginner</option>
                                   <option value="intermediate">Intermediate</option>
                                   <option value="advanced">Advanced</option>
                               </select>
                           </div>
                           <div class="form-group">
                               <label for="afrostyle-experience">Afro Style Experience</label>
                               <select class="form-control" id="afrostyleExp" name="afrostyleExp">
                                   <option value="none">None</option>
                                   <option value="beginner">Beginner</option>
                                   <option value="intermediate">Intermediate</option>
                                   <option value="advanced">Advanced</option>
                               </select>
                           </div>
                           <div class="form-group">
                               <label for="ladystyle-experience">Lady Style Experience</label>
                               <select class="form-control" id="ladystyleExp" name="ladystyleExp">
                                   <option value="none">None</option>
                                   <option value="beginner">Beginner</option>
                                   <option value="intermediate">Intermediate</option>
                                   <option value="advanced">Advanced</option>
                               </select>
                           </div>
                           <div class="form-group">
                            <label for="otherDanceExp">Other Dance Experience</label>
                            <textarea  rows="50" cols="65"  class="form-control" id="otherDanceExp" name="otherDanceExp" rows="4"></textarea>
                           </div>
        
                           <div class="form-group">
                            <span class="input-group-text" id="registration_date">Registration date</span>
                            <input type="datetime-local"  name="registration_date" value="<?php echo $registration_date;?>" readonly style ="background-color: #ccc; ">
                            </div>
        
                        </fieldset>
        
                    </form>
                </div>
        
            </div>


               
               <!------------------------------------------------------------>
            </div>

            <div class="col-four tab-full pull-right info-contact">

                <div class="info-block">
                    <h3>Start A Conversation</h3>
                    <p>
                        <a href="mailto:#0" class="info-email">dancei.island.cy@gmail.com</a><br>
                        <a href="tel:+35799809260" class="'info-phone">+35799809260</a>
                        <a href="tel:+35797932635s" class="'info-phone">+35797932635</a>
                    </p>
                </div>

                <div class="info-block">
                    <h3>Visit Our Team</h3>
                    
                    <p class="info-address">
                        irakleitou 16<br>
                        Paralimni<br>
                        Cyprus
                    </p>
                </div>

                <div class="info-block">
                    <h3>Find Us On</h3>
                    
                    <ul class="info-social">
                        <li>
                            <a href="https://www.facebook.com/VasilisMarinaDanceislandcy/"><i class="fab fa-facebook" aria-hidden="true"></i>
                            <span>Danceislandcy</span></a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/DanceIslandCy/" ><i class="fab fa-facebook" aria-hidden="true"></i>
                            <span>VasilisMarina</span></a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/danceislandcy"><i class="fab fa-instagram" aria-hidden="true"></i>
                            <span>danceislandcy</span></a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/@DanceIslandC"><i class="fab fa-youtube"  aria-hidden="true"></i>
                            <span>YouTube Channel</span></a>
                        </li>
                        <li>
                            <a href="https://www.danceislandcy.com"><i class="fab fa-connectdevelop" aria-hidden="true"></i>
                            <span>Webpage</span></a>
                        </li>
                    </ul>
                </div>
                
            </div>  <!-- end info contact -->

        </div>  <!-- end info wrapper -->

    </div> <!-- end s-info -->


    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader">
            <div class="line-scale-pulse-out">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>

    <!-- Java Script
    ================================================== -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
    <script src="js/AutoFillFullName.js"></script>



 



       <!-- JS -->
       <script src="vendor/jquery/jquery.min.js"></script>
       <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>
       <script src="vendor/jquery-validation/dist/additional-methods.min.js"></script>
       <script src="vendor/jquery-steps/jquery.steps.min.js"></script>
       <script src="js/InsertData.js"></script>
  <!-- Link to the external JavaScript file -->
  <script src="js/geolocation.js"></script>


</body>

</html>