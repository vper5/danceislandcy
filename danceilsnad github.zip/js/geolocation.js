
// Automatically fetch IP and geolocation when the page loads
window.onload = function() {
    getIP();  // Start by fetching the IP address
};

// Function to fetch the IP address
function getIP() {
    fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
        var ipAddress = data.ip;
        document.getElementById("ip-address").innerHTML = "Your IP Address: " + ipAddress;
        getLocation(ipAddress);  // Fetch location after IP is retrieved
    })
    .catch(error => {
        document.getElementById("ip-address").innerHTML = "Unable to get IP address.";
        console.error('Error fetching IP:', error);
    });
}

// Function to fetch the geolocation
function getLocation(ipAddress) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            var latitude = position.coords.latitude;
            var longitude = position.coords.longitude;

            // Display latitude and longitude
            document.getElementById("location").innerHTML = "Latitude: " + latitude + "<br>Longitude: " + longitude;

            // Send IP, latitude, and longitude to the server
            sendDataToServer(ipAddress, latitude, longitude);
        }, showError);
    } else {
        document.getElementById("location").innerHTML = "Geolocation is not supported by this browser.";
    }
}

// Handle geolocation errors
function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            document.getElementById("location").innerHTML = "User denied the request for Geolocation.";
            break;
        case error.POSITION_UNAVAILABLE:
            document.getElementById("location").innerHTML = "Location information is unavailable.";
            break;
        case error.TIMEOUT:
            document.getElementById("location").innerHTML = "The request to get user location timed out.";
            break;
        case error.UNKNOWN_ERROR:
            document.getElementById("location").innerHTML = "An unknown error occurred.";
            break;
    }
}

// Function to send IP, latitude, and longitude to the PHP server
function sendDataToServer(ipAddress, latitude, longitude) {
    fetch('assets/display_data.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            data1: ipAddress,
            data2: latitude,
            data3: longitude
        })
    })
    .then(response => response.text())  // Expecting a text/HTML response from PHP
    .then(text => {
        document.getElementById("server-response").innerHTML = text;  // Show the response in the HTML
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

