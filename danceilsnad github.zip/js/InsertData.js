(function($) {
    $(document).ready(function() {
        var form = $("#signup-form");
        form.steps({
      onStepChanging: function(event, currentIndex, newIndex) {
          // Validate current step fields
          var valid = form.valid(); // Assuming jQuery validate is used for field validation
          if (!valid) {
              form.validate().focusInvalid(); // Focus on the first invalid field
              return false; // Prevent going to the next step
          }
          return true; // Proceed to the next step if valid
      },
            headerTag: "h3",
            bodyTag: "fieldset",
            transitionEffect: "fade",
            labels: {
                previous: 'Previous',
                next: 'Next',
                finish: 'Submit',
                current: ''
            },
            titleTemplate: '<div class="title"><span class="title-text">#title#</span><span class="title-number">0#index#</span></div>',
            onFinished: function(event, currentIndex) {
                // Automatically submit the form when the final step is reached
                form.submit();
            }
        });

    // Add custom validation rule to require at least one dance style to be selected
    $.validator.addMethod("requireDanceSelection", function(value, element) {
        return $("input[name='dances[]']:checked").length > 0; // Check if at least one checkbox is selected
    }, "Please select at least one dance style.");

    // Initialize jQuery validation with the custom rule
    form.validate({
        rules: {
            "dances[]": {
                requireDanceSelection: true // Apply the custom rule to the dance checkboxes
            }
        },
        // Place the error message below the title and above the checkboxes
        errorPlacement: function(error, element) {
            if (element.attr("name") === "dances[]") {
                error.insertAfter("h2"); // Insert the error message after the <h2> title
            } else {
                error.insertAfter(element); // Default behavior for other fields
            }
        },
        highlight: function(element) {
            $(element).addClass('error'); // Add 'error' class to invalid fields
        },
        unhighlight: function(element) {
            $(element).removeClass('error'); // Remove 'error' class when valid
        }
    });

 // Initialize jQuery validation
 form.validate({
    // Prevent default error message display
    errorPlacement: function(error, element) {
        return true; // Suppress error messages
    },
    // Highlight the field with an error class
    highlight: function(element) {
        $(element).addClass('error'); // Add 'error' class to the field
    },
    // Remove the highlight once the field is valid
    unhighlight: function(element) {
        $(element).removeClass('error'); // Remove 'error' class when valid
    }
});



        
    });
  })(jQuery);
  
  
  
  
  
  
  