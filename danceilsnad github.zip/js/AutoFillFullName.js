function updateFullName() {
    // Get the input from the first and second text boxes
    var name = document.getElementById("fname").value;
    var surname = document.getElementById("sname").value;
    // Combine the name and surname, and set it to the third text box
    document.getElementById("Fullname").value = name + " " + surname;
}